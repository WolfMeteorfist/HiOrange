package com.yuanshi.hiorange.activity;

/**
 * Created by Administrator on 2018/3/7.
 */

public interface IUnbindView {

    void unbindSucceed(String result);

    void unbindFailed(String result);

}
