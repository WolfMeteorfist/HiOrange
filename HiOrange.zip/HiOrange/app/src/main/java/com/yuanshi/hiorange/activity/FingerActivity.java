package com.yuanshi.hiorange.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;

import com.yuanshi.hiorange.BaseActivity;

/**
 *
 * @author Zyc
 * @date 2018/3/8
 */

public class FingerActivity extends BaseActivity {



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


}
