package com.yuanshi.hiorange.activity;

/**
 * Created by Administrator on 2018/2/25.
 */

public interface IRegisterView {

    void onRegisterSucceed(String result);

    void onRegisterFailed(String result);

}
