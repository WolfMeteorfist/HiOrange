package com.yuanshi.hiorange.activity;

/**
 * Created by Administrator on 2018/3/7.
 */

public interface IVoiceVew {

    void onReadSucceed(String result);

    void onReadFailed(String result);
}
