package com.yuanshi.hiorange.activity;

/**
 * Created by Administrator on 2018/2/25.
 */

public interface IAddBoxView {

    void onAddSucceed(String result);

    void onAddFailed(String result);

}
